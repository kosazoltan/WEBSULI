// Admin email allowlist - hardcoded admin users
export const ADMIN_EMAILS = [
  'kosa.zoltan.ebc@gmail.com',
  'mszilva78@gmail.com'
];

/**
 * Check if an email belongs to an admin user
 * Case-insensitive comparison
 */
export function isAdmin(email?: string | null): boolean {
  if (!email) return false;
  const normalizedEmail = email.toLowerCase().trim();
  return ADMIN_EMAILS.some(adminEmail => 
    adminEmail.toLowerCase() === normalizedEmail
  );
}

/**
 * Get admin display badge text
 */
export function getAdminBadge(email?: string | null): string | null {
  return isAdmin(email) ? 'Admin' : null;
}

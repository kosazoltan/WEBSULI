import { useEffect, useRef } from "react";
import { Rocket, BookOpen, Users, Sparkles } from "lucide-react";
import EmailSubscribeDialog from "@/components/EmailSubscribeDialog";

interface HeroSectionProps {
  totalFiles?: number;
  totalClassrooms?: number;
  showEmailSubscribe?: boolean;
}

export default function HeroSection({ 
  totalFiles = 0, 
  totalClassrooms = 0, 
  showEmailSubscribe = true 
}: HeroSectionProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const updateCanvasSize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    updateCanvasSize();

    // Constellation Star class
    class ConstellationStar {
      x: number;
      y: number;
      radius: number;
      vx: number;
      vy: number;

      constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
        this.radius = Math.random() * 6 + 3;
        this.vx = (Math.random() - 0.5) * 0.3;
        this.vy = (Math.random() - 0.5) * 0.3;
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;

        if (this.x < 0 || this.x > canvas!.width) this.vx *= -1;
        if (this.y < 0 || this.y > canvas!.height) this.vy *= -1;
      }

      draw() {
        if (!ctx) return;
        
        // Star core
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#ffc107';
        ctx.fill();

        // Star glow
        const gradient = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.radius * 3);
        gradient.addColorStop(0, 'rgba(255, 193, 7, 0.8)');
        gradient.addColorStop(1, 'rgba(255, 193, 7, 0)');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius * 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Create constellation stars
    const constellationStars: ConstellationStar[] = [];
    for (let i = 0; i < 12; i++) {
      constellationStars.push(new ConstellationStar(
        Math.random() * canvas.width,
        Math.random() * canvas.height
      ));
    }

    // Draw constellation lines
    const drawConstellationLines = () => {
      if (!ctx) return;
      
      for (let i = 0; i < constellationStars.length; i++) {
        for (let j = i + 1; j < constellationStars.length; j++) {
          const dx = constellationStars[i].x - constellationStars[j].x;
          const dy = constellationStars[i].y - constellationStars[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 180) {
            ctx.beginPath();
            ctx.moveTo(constellationStars[i].x, constellationStars[i].y);
            ctx.lineTo(constellationStars[j].x, constellationStars[j].y);
            const opacity = 1 - distance / 180;
            ctx.strokeStyle = `rgba(255, 152, 0, ${opacity * 0.6})`;
            ctx.lineWidth = 2;
            ctx.stroke();
          }
        }
      }
    };

    // Animation loop
    let animationFrameId: number;
    const animate = () => {
      if (!ctx) return;
      
      ctx.clearRect(0, 0, canvas!.width, canvas!.height);

      drawConstellationLines();
      constellationStars.forEach(star => {
        star.update();
        star.draw();
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    // Resize handler
    const handleResize = () => {
      updateCanvasSize();
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="relative text-center mb-6 sm:mb-8 fold:py-6 py-8 sm:py-10 fold:px-4 px-6 sm:px-10 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-white via-orange-50 to-amber-50 dark:from-gray-900 dark:via-orange-950/50 dark:to-amber-950/50 shadow-xl sm:shadow-2xl overflow-hidden border-3 border-orange-200/40 dark:border-orange-800/40">
      {/* Canvas background - Constellation animation */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none opacity-12"
        style={{ width: '100%', height: '100%' }}
      />
      
      <div className="relative z-10">
        {/* Logo with pulse animation */}
        <div className="inline-block p-3 rounded-full bg-gradient-to-br from-orange-500 to-amber-400 mb-4 shadow-2xl animate-pulse-glow border-4 border-white/80 dark:border-orange-300/30">
          <Rocket className="w-8 h-8 xs:w-9 xs:h-9 sm:w-10 sm:h-10 text-white drop-shadow-lg" />
        </div>
        
        {/* Title */}
        <h1 className="text-xl xs:text-2xl sm:text-3xl lg:text-4xl font-extrabold mb-2 bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 dark:from-orange-400 dark:via-amber-300 dark:to-orange-400 bg-clip-text text-transparent drop-shadow-sm">
          Anyagok Profiknak
        </h1>
        
        {/* Tagline */}
        <p className="text-xs xs:text-sm text-orange-700 dark:text-orange-400 font-semibold uppercase mb-4 sm:mb-6 tracking-wider opacity-90" data-testid="text-quote-inspiration">
          „Ha arra számítasz, hogy egyszerű dolgod lesz. Tudd, igen nagyot fogsz csalódni!"
        </p>
      
        {/* Stats - only show if files exist */}
        {totalFiles > 0 && (
          <div className="flex flex-col fold:gap-2 xs:flex-row xs:items-center xs:justify-center xs:gap-4 sm:gap-6 text-xs xs:text-sm mb-4 sm:mb-5">
            <div className="flex items-center justify-center gap-1.5 xs:gap-2 bg-orange-100/60 dark:bg-orange-900/30 px-3 py-2 rounded-full border-2 border-orange-300/40 dark:border-orange-700/40">
              <BookOpen className="w-3.5 h-3.5 xs:w-4 xs:h-4 text-orange-600 dark:text-orange-400" />
              <span className="font-semibold text-foreground">{totalFiles} anyag</span>
            </div>
            <div className="flex items-center justify-center gap-1.5 xs:gap-2 bg-orange-100/60 dark:bg-orange-900/30 px-3 py-2 rounded-full border-2 border-orange-300/40 dark:border-orange-700/40">
              <Users className="w-3.5 h-3.5 xs:w-4 xs:h-4 text-orange-600 dark:text-orange-400" />
              <span className="font-semibold text-foreground">{totalClassrooms} osztály</span>
            </div>
            <div className="flex items-center justify-center gap-1.5 xs:gap-2 bg-orange-100/60 dark:bg-orange-900/30 px-3 py-2 rounded-full border-2 border-orange-300/40 dark:border-orange-700/40">
              <Sparkles className="w-3.5 h-3.5 xs:w-4 xs:h-4 text-orange-600 dark:text-orange-400" />
              <span className="font-semibold text-foreground">Ingyenes</span>
            </div>
          </div>
        )}
        
        {/* Email Subscribe Button */}
        {showEmailSubscribe && (
          <div className="flex justify-center">
            <EmailSubscribeDialog />
          </div>
        )}
      </div>
    </div>
  );
}

import passport from "passport";
import session from "express-session";
import type { Express, RequestHandler } from "express";
import MemoryStore from "memorystore";
import { storage } from "./storage";
import { isAdmin } from "./utils/auth";

// Temporary Dev Auth replacement for Replit OIDC
// This allows local development without Replit dependencies

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const MemStore = MemoryStore(session);
  const sessionStore = new MemStore({
    checkPeriod: sessionTtl,
  });

  return session({
    secret: process.env.SESSION_SECRET || "dev_secret_key_12345",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // False for local dev (HTTP)
      sameSite: "lax",
      maxAge: sessionTtl,
    },
  });
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());
  app.use(passport.initialize());
  app.use(passport.session());

  passport.serializeUser((user: any, cb) => cb(null, user));
  passport.deserializeUser((user: any, cb) => cb(null, user));

  // MOCK LOGIN ROUTE specifically for local dev
  app.get("/api/login", async (req, res) => {
    // Automatically log in as the first admin in the list
    const adminEmail = "kosa.zoltan.ebc@gmail.com";

    // Check if user exists in DB, if not create/upsert
    // This mocks what the OIDC flow would do
    const mockUser = {
      id: "dev-admin-id",
      email: adminEmail,
      firstName: "Dev",
      lastName: "Admin",
      profileImageUrl: "https://via.placeholder.com/150",
      claims: {
        sub: "dev-admin-id",
        email: adminEmail,
        first_name: "Dev",
        last_name: "Admin"
      },
      expires_at: Math.floor(Date.now() / 1000) + 3600 * 24 // 1 day
    };

    // Upsert into storage so app logic works
    await storage.upsertUser({
      id: mockUser.id,
      email: mockUser.email,
      firstName: mockUser.firstName,
      lastName: mockUser.lastName,
      profileImageUrl: mockUser.profileImageUrl,
      isAdmin: true
    });

    req.login(mockUser, (err) => {
      if (err) {
        console.error("Login error:", err);
        return res.status(500).send("Login failed");
      }
      res.redirect("/");
    });
  });

  app.get("/api/logout", (req, res) => {
    req.logout(() => {
      req.session.destroy((err) => {
        if (err) console.error("Session destroy error:", err);
        res.clearCookie("connect.sid");
        res.redirect("/");
      });
    });
  });

  // Fake callback route just in case
  app.get("/api/callback", (req, res) => {
    res.redirect("/");
  });
}

export const isAuthenticated: RequestHandler = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export const isAuthenticatedAdmin: RequestHandler = (req, res, next) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const user = req.user as any;
  if (!isAdmin(user.email)) {
    return res.status(403).json({ message: "Forbidden - Admin access required" });
  }
  next();
};

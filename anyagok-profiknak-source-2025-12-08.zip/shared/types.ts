// This file is intentionally empty
// Authentication has been completely removed from the platform (November 2025)
// The platform is fully public and open - no authentication is required for any features

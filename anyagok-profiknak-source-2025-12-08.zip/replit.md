# Anyagok Profiknak - HTML Platform

## Overview
"Anyagok Profiknak" is an educational HTML materials platform for professionals, designed with a vibrant, playful interface. It features AI-assisted content creation, live HTML previews, and a colorful design system. The platform provides a secure and engaging educational experience, with authenticated admin users having exclusive access to content creation, editing, and AI features, while public users can view and interact with published materials.

## User Preferences
- Preferred communication style: Professional, clear Hungarian language
- Target audience: Professionals sharing HTML materials for students
- Design approach: Scientific yet playful - professional educational platform
- Visual style: **Hero Section**: Canvas-based "Educational Constellation" design with animated star constellation patterns (orange/gold warm science colors), pulsing logo with animate-pulse-glow CSS keyframe animation. **Content**: Classroom-specific color coding with vibrant badges.
- Color palette: Orange/gold gradient for hero (warm science, inspirational cosmic mood), educational cards maintain classroom-specific colors
- Security: Code is not accessible to viewers, only preview

## System Architecture

### UI/UX Decisions
The platform uses a scientific yet playful aesthetic. The hero section features a canvas-based "Educational Constellation" design with animated star constellation patterns (orange/gold warm science colors), creating an inspirational cosmic mood and professional first impression. Content cards maintain vibrant classroom-specific colors. The UI features a dual responsive layout for mobile and desktop, with specific color schemes for admin filter badges and public classroom badges. SimpleHtmlUpload dialog optimized for compact viewing without scrolling.

### Technical Implementations
The frontend is built with React, TypeScript, and Vite, utilizing Shadcn UI, Radix UI, and Tailwind CSS. It uses TanStack Query for state management, Wouter for routing, and React Hook Form with Zod for validation. The backend employs Express.js and TypeScript with Neon PostgreSQL and Drizzle ORM for data persistence.

**Database Architecture**: Utilizes Neon PostgreSQL with separate development and production databases. A robust syncing mechanism allows admins to copy production data to the development environment, incorporating security validations to prevent data loss. The schema uses full PostgreSQL-native types.

**Security**: Features include robust admin authentication via Replit Auth (OIDC-based) with hardcoded admin emails, router-level middleware protection for admin API endpoints, XSS protection, and hardened iframe sandboxing. Frontend protection for admin routes ensures unauthorized users cannot access privileged UI elements.

**Authentication System**: Replit Auth is used for session management with express-session. Admin-only access controls are enforced, protecting sensitive operations and routes. A nested iframe solution addresses third-party cookie blocking issues for authentication.

**Automatic Backup System**: A file-based backup system performs daily scheduled backups and event-driven backups (on material CRUD operations) with a 30-day retention policy. Backups are stored locally, and an admin UI allows listing, downloading, and restoring backups.

### Feature Specifications
Key features include:
- **Admin Dashboard**: Content management (create, edit, delete), drag-and-drop material reordering, draft management, and publishing.
- **Material Creation**: Supports quick HTML uploads, an advanced AI-powered material creator (converting PDF/DOCX/JPG/PNG to HTML), and direct native PDF uploads rendered with `@react-pdf-viewer`.
- **Public Viewing**: All materials are publicly viewable without authentication and sorted chronologically.
- **Live HTML Previews**: Interactive HTML previews are provided in responsive, sandboxed iframes with extended permissions (allow-scripts, allow-forms, allow-popups, allow-modals, allow-same-origin, allow-downloads).
- **AI Integration**: Enhanced Material Creator with Claude Opus 4.1 for HTML generation (45 szöveges feladat + 75 kvíz kérdés generálás, piros/zöld ellenőrzés, osztályzat), OpenAI GPT-5 for document analysis (ok-okozati összefüggések, tanári magyarázatok, hallucináció-mentes), and HTML Fixer AI chat.
- **Email System**: Gmail-based transactional emails for notifications and multi-classroom subscriptions.
- **Tracking**: Monitors material creation/editing, anonymous viewing, and AI generation requests.
- **Accessibility**: Universal Text-to-Speech (Google Translate TTS) and PWA support.
- **System Management**: Automatic backups, manual restore, editable AI system prompts, and source code export.
- **Student Interaction**: Materials include a `sendResultEmail` JavaScript function for students to submit quiz/test results.
- **Type Safety**: Complete TypeScript type safety across all endpoints with Zod validation.

### System Design Choices
- **Admin-Only Access Control**: Admin authentication is required for all CRUD operations and admin features, while public viewing remains open. Frontend UI protection prevents unauthorized access to privileged elements.
- **Code Protection**: HTML content is not directly exposed; previews are rendered in sandboxed iframes.
- **Automatic Classroom Classification**: Materials are categorized based on their title content.
- **Material Ordering**: Implemented with `@dnd-kit` and a `displayOrder` field, allowing admins to reorder materials with persistence.
- **Neon PostgreSQL Architecture**: Uses separate databases for development and production, leveraging HTTP connection pooling and native PostgreSQL types for optimal performance.
- **Cross-Browser HTML Rendering**: Uploaded HTML materials are wrapped in a minimal responsive container for compatibility.

## External Dependencies

- **UI & Component Libraries**: Radix UI, Shadcn UI, Lucide React, Tailwind CSS, @dnd-kit.
- **Data & Forms**: TanStack Query, React Hook Form, Zod, Drizzle ORM.
- **Email Service**: Gmail (via Replit connector using `googleapis`).
- **Text-to-Speech**: `google-tts-api`.
- **AI Services**: Anthropic Claude Opus 4.1 (HTML tananyag generálás), Claude Sonnet 4.5 (HTML javítás), OpenAI GPT-5 (dokumentum elemzés, szöveg generálás).
- **Push Notifications**: `web-push`.
- **Document Processing**: `mammoth` (DOCX to HTML), `@react-pdf-viewer` (PDF viewing).
- **PDF Support**: `pdfjs-dist` with local worker and standard fonts.
- **Fonts**: Google Fonts (Poppins, Inter, JetBrains Mono).
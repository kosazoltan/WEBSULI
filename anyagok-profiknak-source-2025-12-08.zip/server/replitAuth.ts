import * as client from "openid-client";
import { Strategy, type VerifyFunction } from "openid-client/passport";
import passport from "passport";
import session from "express-session";
import type { Express, RequestHandler } from "express";
import memoize from "memoizee";
import MemoryStore from "memorystore";
import { storage } from "./storage";
import { isAdmin } from "./utils/auth";

// CRITICAL: Crash fast if required env vars missing
if (!process.env.REPL_ID) {
  throw new Error('FATAL: REPL_ID environment variable is required for authentication');
}
if (!process.env.SESSION_SECRET) {
  throw new Error('FATAL: SESSION_SECRET environment variable is required for session management');
}

// Memoize issuer discovery (expensive operation, cache for 1 hour)
const getIssuer = memoize(
  async () => {
    const issuerUrl = new URL(process.env.ISSUER_URL ?? "https://replit.com/oidc");
    return await client.discovery(issuerUrl, process.env.REPL_ID!);
  },
  { maxAge: 3600 * 1000 }
);

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const MemStore = MemoryStore(session);
  const sessionStore = new MemStore({
    checkPeriod: sessionTtl,
  });
  
  // Detect if running inside Replit iframe (Webview)
  const isReplitIframe = process.env.REPLIT_DEV_DOMAIN !== undefined;
  const isProduction = process.env.NODE_ENV === "production";
  
  // CRITICAL: sameSite='none' requires secure=true (browser requirement)
  const useSameSiteNone = isProduction || isReplitIframe;
  
  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      // CRITICAL: secure=true when using sameSite='none' (browser requirement)
      // secure=true for HTTPS (Replit, production), secure=false only for local HTTP
      secure: useSameSiteNone,
      // CRITICAL: sameSite='none' required for Replit iframe OAuth flow
      // In production or Replit iframe: 'none' (allows cross-site cookies)
      // In local development: 'lax' (standard security)
      sameSite: useSameSiteNone ? "none" : "lax",
      maxAge: sessionTtl,
    },
  });
}

function updateUserSession(
  user: any,
  tokens: client.TokenEndpointResponse & client.TokenEndpointResponseHelpers
) {
  user.claims = tokens.claims();
  user.access_token = tokens.access_token;
  user.refresh_token = tokens.refresh_token;
  user.expires_at = user.claims?.exp;
}

async function upsertUser(claims: any) {
  const email = claims["email"];
  const adminStatus = isAdmin(email);
  
  await storage.upsertUser({
    id: claims["sub"],
    email: email,
    firstName: claims["first_name"],
    lastName: claims["last_name"],
    profileImageUrl: claims["profile_image_url"],
    isAdmin: adminStatus,
  });
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());
  app.use(passport.initialize());
  app.use(passport.session());

  // Pre-discover issuer at boot time
  const issuer = await getIssuer();

  const verify: VerifyFunction = async (
    tokens: client.TokenEndpointResponse & client.TokenEndpointResponseHelpers,
    verified: passport.AuthenticateCallback
  ) => {
    const user = {};
    updateUserSession(user, tokens);
    await upsertUser(tokens.claims());
    verified(null, user);
  };

  // Keep track of registered strategies (keyed by full callback URL)
  const registeredStrategies = new Map<string, Strategy>();

  // Helper: create or retrieve strategy for specific callback URL
  const getStrategy = (callbackURL: string): Strategy => {
    if (!registeredStrategies.has(callbackURL)) {
      const strategy = new Strategy(
        {
          name: `replitauth:${callbackURL}`,
          config: issuer, // Use the issuer directly (it's already a Configuration object)
          scope: "openid email profile offline_access",
          callbackURL, // Dynamic redirect_uri per request
        },
        verify,
      );
      
      passport.use(strategy);
      registeredStrategies.set(callbackURL, strategy);
    }
    return registeredStrategies.get(callbackURL)!;
  };

  passport.serializeUser((user: Express.User, cb) => cb(null, user));
  passport.deserializeUser((user: Express.User, cb) => cb(null, user));

  app.get("/api/login", (req, res, next) => {
    // Build callback URL - use Replit dev domain or custom domain, NOT localhost
    let host: string;
    if (process.env.NODE_ENV === "production" && process.env.CUSTOM_DOMAIN) {
      host = process.env.CUSTOM_DOMAIN;
    } else if (process.env.REPLIT_DEV_DOMAIN) {
      host = process.env.REPLIT_DEV_DOMAIN;
    } else {
      // Fallback to request host (for local testing outside Replit)
      host = req.get('host')!;
    }
    
    const callbackURL = `https://${host}/api/callback`;
    
    console.log('[AUTH] Login request:', {
      host,
      callbackURL,
      replId: process.env.REPL_ID,
    });
    
    const strategy = getStrategy(callbackURL);
    passport.authenticate(strategy.name, {
      prompt: "login consent",
      scope: ["openid", "email", "profile", "offline_access"],
    })(req, res, next);
  });

  app.get("/api/callback", (req, res, next) => {
    // Build callback URL - must match login callback URL
    let host: string;
    if (process.env.NODE_ENV === "production" && process.env.CUSTOM_DOMAIN) {
      host = process.env.CUSTOM_DOMAIN;
    } else if (process.env.REPLIT_DEV_DOMAIN) {
      host = process.env.REPLIT_DEV_DOMAIN;
    } else {
      host = req.get('host')!;
    }
    
    const callbackURL = `https://${host}/api/callback`;
    
    console.log('[AUTH] Callback request:', {
      host,
      callbackURL,
      hasCode: !!req.query.code,
      hasError: !!req.query.error,
      error: req.query.error,
      errorDescription: req.query.error_description,
    });
    
    const strategy = getStrategy(callbackURL);
    passport.authenticate(strategy.name, {
      successReturnToOrRedirect: "/",
      failureRedirect: "/api/login",
    })(req, res, next);
  });

  app.get("/api/logout", async (req, res) => {
    const issuer = await getIssuer();
    req.logout(() => {
      // CRITICAL: Destroy the session explicitly to prevent re-authentication on page reload
      // req.logout() only clears req.user but leaves the session intact
      req.session.destroy((err) => {
        if (err) {
          console.error('[AUTH] Session destroy error:', err);
        }
        // Clear the session cookie
        res.clearCookie('connect.sid');
        
        // Redirect to OIDC provider end session URL
        res.redirect(
          client.buildEndSessionUrl(issuer, {
            client_id: process.env.REPL_ID!,
            post_logout_redirect_uri: `${req.protocol}://${req.get('host')}`,
          }).href
        );
      });
    });
  });
}

export const isAuthenticated: RequestHandler = async (req, res, next) => {
  const user = req.user as any;

  if (!req.isAuthenticated() || !user.expires_at) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const now = Math.floor(Date.now() / 1000);
  if (now <= user.expires_at) {
    return next();
  }

  const refreshToken = user.refresh_token;
  if (!refreshToken) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }

  try {
    const issuer = await getIssuer();
    const tokenResponse = await client.refreshTokenGrant(issuer, refreshToken);
    updateUserSession(user, tokenResponse);
    return next();
  } catch (error) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
};

// Admin-only middleware
export const isAuthenticatedAdmin: RequestHandler = async (req, res, next) => {
  const user = req.user as any;

  // First check authentication
  if (!req.isAuthenticated() || !user.claims) {
    return res.status(401).json({ message: "Unauthorized - Please login" });
  }

  // Check if user is admin
  const userEmail = user.claims.email;
  if (!isAdmin(userEmail)) {
    return res.status(403).json({ message: "Forbidden - Admin access required" });
  }

  // Check token expiry
  const now = Math.floor(Date.now() / 1000);
  if (now > user.expires_at) {
    const refreshToken = user.refresh_token;
    if (!refreshToken) {
      return res.status(401).json({ message: "Unauthorized - Session expired" });
    }

    try {
      const issuer = await getIssuer();
      const tokenResponse = await client.refreshTokenGrant(issuer, refreshToken);
      updateUserSession(user, tokenResponse);
    } catch (error) {
      return res.status(401).json({ message: "Unauthorized - Session expired" });
    }
  }

  next();
};

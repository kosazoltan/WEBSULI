import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import * as schema from "@shared/schema";

// Select database URL based on environment with fallback
const isDevelopment = process.env.NODE_ENV === 'development';

// CRITICAL SAFETY: Fallback to production database if dev database not configured OR invalid
// This prevents crashes when DEV_DATABASE_URL is missing or points to non-existent database
let DATABASE_URL: string;
let usingFallback = false;

async function testDatabaseConnection(url: string): Promise<boolean> {
  try {
    const testSql = neon(url);
    // Simple test query - SELECT 1 is the fastest way to test connection
    await testSql`SELECT 1`;
    return true;
  } catch (error: any) {
    console.error(`[NEON] ❌ Database connection test failed: ${error.message}`);
    return false;
  }
}

// Determine which database URL to use (with validation)
if (isDevelopment && process.env.DEV_DATABASE_URL) {
  // Try dev database first
  const devConnValid = await testDatabaseConnection(process.env.DEV_DATABASE_URL);
  
  if (devConnValid) {
    DATABASE_URL = process.env.DEV_DATABASE_URL;
  } else {
    // DEV_DATABASE_URL set but invalid → fallback to production database
    DATABASE_URL = process.env.DATABASE_URL!;
    usingFallback = true;
    console.warn('[NEON] ⚠️  DEV_DATABASE_URL points to invalid/non-existent database');
    console.warn('[NEON] ⚠️  Falling back to DATABASE_URL (production)');
    console.warn('[NEON] ⚠️  Production→Dev sync will be DISABLED for safety');
  }
} else if (isDevelopment) {
  // DEV_DATABASE_URL not set → fallback to production database
  DATABASE_URL = process.env.DATABASE_URL!;
  usingFallback = true;
  console.warn('[NEON] ⚠️  DEV_DATABASE_URL not set - using DATABASE_URL as fallback');
  console.warn('[NEON] ⚠️  Production→Dev sync will be DISABLED for safety');
} else {
  DATABASE_URL = process.env.DATABASE_URL!;
}

if (!DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is not set');
}

// Create Neon HTTP client
const sql = neon(DATABASE_URL);

// Create Drizzle instance
export const db = drizzle(sql, { schema });

// Export flag to indicate if we're using fallback (for disabling sync features)
export const isUsingProductionAsDev = usingFallback;

if (usingFallback) {
  console.log('[NEON] ✅ Database initialized (DEV mode using PRODUCTION database - sync DISABLED)');
} else {
  console.log(`[NEON] ✅ Database initialized (${isDevelopment ? 'DEV' : 'PRODUCTION'} PostgreSQL)`);
}
